/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/hr/currency",{HKD_displayName:"hongkon\u0161ki dolar",CHF_displayName:"\u0161vicarski franak",JPY_symbol:"\u00a5",CAD_displayName:"kanadski dolar",HKD_symbol:"HKD",CNY_displayName:"kineski yuan",USD_symbol:"USD",AUD_displayName:"australski dolar",JPY_displayName:"japanski jen",CAD_symbol:"CAD",USD_displayName:"ameri\u010dki dolar",CNY_symbol:"CNY",GBP_displayName:"britanska funta",GBP_symbol:"GBP",AUD_symbol:"AUD",EUR_displayName:"euro"});

define(
//begin v1.x content
{
	"HKD_displayName": "ដុល្លារ ហុងកុង",
	"CHF_displayName": "ហ្វ្រង់ ស្វីស",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "ដុល្លារ កាណាដា",
	"HKD_symbol": "HK$",
	"CNY_displayName": "យ៉ន់ ចិន",
	"USD_symbol": "US$",
	"AUD_displayName": "ដុល្លារ អូស្ត្រាលី",
	"JPY_displayName": "យេន ជប៉ុន",
	"CAD_symbol": "CA$",
	"USD_displayName": "ដុល្លារ អាមេរិក",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "ផោនស្ទែរលិញ ចក្រភពអង់គ្លេស",
	"GBP_symbol": "£",
	"AUD_symbol": "A$",
	"EUR_displayName": "អឺរ៉ូ"
}
//end v1.x content
);
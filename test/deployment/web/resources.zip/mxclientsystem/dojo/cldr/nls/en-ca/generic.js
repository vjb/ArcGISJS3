/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-ca/generic",{"dateFormatItem-yyyyMEd":"E, GGGGG y-MM-dd","dateFormat-short":"GGGGG y-MM-dd","dateFormatItem-yyyyM":"GGGGG y-MM","dateFormatItem-MEd":"E, MM-dd","dateFormatItem-Md":"MM-dd","dateFormatItem-yyyyMd":"GGGGG y-MM-dd"});

/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/zh-hk/currency",{HKD_displayName:"\u6e2f\u5e63",JPY_symbol:"\u00a5",CAD_displayName:"\u52a0\u5e63",CNY_displayName:"\u4eba\u6c11\u5e63",USD_symbol:"$",AUD_displayName:"\u6fb3\u5e63",JPY_displayName:"\u65e5\u5713",$locale:"zh-hant-hk",CNY_symbol:"CN\u00a5",GBP_displayName:"\u82f1\u938a",EUR_displayName:"\u6b50\u5143"});
